# epidemio · painel de demonstração

Esta cópia contém **810 artigos inteiramente fictícios**, distribuídos entre 2023 e 2026. Pessoas, instituições, títulos, datas, contagens e resultados foram inventados. Os números não descrevem o desempenho da revista. A marca epidemio e a geografia do Brasil foram preservadas para a apresentação.

## Abrir e apresentar

1. Abra `Abrir-demonstracao.html` com duplo clique no Finder. Se necessário, use **Abrir com → Google Chrome**.
2. Navegue pelas seções e altere os filtros normalmente. O HTML já contém os dados, o logo, o mapa e os gráficos; não precisa de internet nem instalação.
3. Use **Reiniciar demonstração** para voltar aos anos e tipos de artigo iniciais.

A referência dos prazos é **19/11/2026**, mantida fixa para que ensaios, prints e vídeos mostrem as mesmas contagens. O filtro de data permite testar os alertas em outra referência; os blocos por editor mantêm a referência fixa, explicitada em seu texto.

O aviso **DEMONSTRAÇÃO — DADOS FICTÍCIOS** acompanha a navegação. Mantenha-o visível nas apresentações. Algumas lacunas e sobreposições são intencionais para ilustrar o quadro de conferência.

## Separação do painel oficial

Esta pasta é exclusiva da demonstração. Não possui conexão com Google Sheets, credenciais, senha de produção ou rotina de publicação. Alterações nesta cópia não são enviadas ao painel oficial. Para uma futura manutenção do oficial, trabalhe em seu projeto original, sem copiar esta base ou substituir arquivos pelos desta demonstração.

## Compartilhar com colegas

O pacote de demonstração contém o código de interface e cálculos, um gerador de dados fictícios, um importador de planilha e instruções de adaptação. Compartilhe **este pacote**, em vez da pasta do projeto oficial, que pode conter dados e configurações privados.

- `documentacao/ADAPTAR-PARA-OUTRA-REVISTA.md`: estrutura esperada e regras a revisar.
- `modelos/Modelo-Artigos-FICTICIO.xlsx`: aba **Artigos** com cabeçalhos e dez exemplos fictícios; aba **Como usar** com instruções.
- `documentacao/ROTEIRO-DE-APRESENTACAO.md`: sugestão de apresentação curta.
- `dist/`: código editável, gráficos e dados sintéticos.
- `adaptacao/`: importador de Excel como ponto de partida para outra implantação.
- `scripts/`: geração da base e do HTML portátil.
- `tests/`: verificações dos cenários e do isolamento da demonstração.

O Excel ilustra o formato de entrada; não é a fonte ativa desta demonstração. Alterá-lo não muda automaticamente o painel.

## Para quem editar o código

O visual usa HTML, CSS e JavaScript sem bibliotecas externas no navegador. Para regenerar os dados fictícios e o HTML, execute na pasta do pacote, com Python 3:

```sh
python3 scripts/gerar_dados_ficticios.py
python3 scripts/gerar_html_portatil.py
```

O primeiro comando recria `dist/demo-data.js` e os exemplos CSV/JSON. O segundo recompõe `Abrir-demonstracao.html` a partir de `dist/`. O modelo XLSX entregue é um exemplo estático e não é regenerado por esses comandos. Após editar HTML, CSS ou JavaScript em `dist/`, basta executar o segundo comando.

Com Node.js disponível, `npm test` executa os testes; não requer instalar pacotes JavaScript. As alterações de regras devem vir acompanhadas da revisão dos testes e dos textos explicativos.

O desenho do mapa deriva de malha simplificada do IBGE, com atribuição preservada no painel. A marca epidemio identifica a experiência original; uma implantação por outra revista deve usar sua própria identidade visual. Este pacote não atribui direitos sobre marcas de terceiros nem define uma licença geral para publicação aberta do projeto.
