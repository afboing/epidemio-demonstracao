import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DEMO_DATA as data,DEMO_REFERENCE as ref} from '../dist/demo-data.js';
import {summary,alertReasons,daysBetween,effectiveDate,editorQueues,filterArticleType,firstDecisionMeasure,annualTrends} from '../dist/metrics.js';

test('Base independente: 810 códigos fictícios, quatro coortes e nenhum vínculo externo',()=>{
 assert.equal(data.synthetic,true);assert.equal(data.records.length,810);
 assert.equal(new Set(data.records.map(r=>r.code)).size,810);
 assert.deepEqual([...new Set(data.records.map(r=>r.year))],[2023,2024,2025,2026]);
 for(const r of data.records){assert.match(r.code,/^202[3-6]-DEMO-\d{4}$/);assert.match(r.title,/^\[Simulação/);assert.match(r.eic,/^Editor [A-D] \(fictício\)$/);assert.ok(!r.institution||r.institution.startsWith('Instituição Fictícia'));}
 for(const s of data.sources){assert.equal(s.kind,'synthetic');assert.ok(!s.url&&!s.spreadsheetId);}
});
test('Cronologia válida até a referência fixa; ausência preservada',()=>{
 for(const r of data.records){
  for(const field of ['submitted','adjusted','decided','published','sentProduction','reviewInvitedAt','reviewCompletedAt'])if(r[field]){assert.ok(daysBetween(r[field],ref)!==null,`${r.code} ${field}`);}
  if(r.adjusted)assert.ok(daysBetween(r.submitted,r.adjusted)!==null);
  for(const field of ['decided','published','reviewInvitedAt'])if(r[field])assert.ok(daysBetween(effectiveDate(r),r[field])!==null,`${r.code} ${field}`);
  if(r.published)assert.ok(daysBetween(r.decided,r.published)!==null);
  if(r.reviewCompletedAt)assert.ok(daysBetween(r.reviewInvitedAt,r.reviewCompletedAt)!==null);
  if(r.reviewAccepted!==null)assert.ok(r.reviewAccepted<=r.reviewInvited);
 }
});
test('As cinco regras de alerta têm exemplos e não duplicam artigos',()=>{
 const rows=data.records.filter(r=>alertReasons(r,ref).length);
 assert.ok(rows.length>0);const reasons=rows.flatMap(r=>alertReasons(r,ref)).join('\n');
 for(const text of ['EC (primeira análise)','EA (definindo revisores)','Revisores (1ª rodada)','EA (já com pareceres)','0 revisores aceitaram','aceites não preenchidos'])assert.ok(reasons.includes(text),text);
 assert.ok(rows.some(r=>alertReasons(r,ref).length===2));
 assert.equal(summary(data.records,ref).counts.alerts,rows.length);
 assert.ok(!rows.some(r=>r.status.includes('2a. ou 3a.')));
});
test('Indicadores continuam ponderados, filtráveis e com lacunas identificáveis',()=>{
 const all=summary(data.records,ref);assert.ok(all.counts.over120>0);assert.ok(all.approvalPublication.missing>0);
 const regular=filterArticleType(data.records,'Número regular');assert.ok(regular.length<data.records.length);
 assert.ok(firstDecisionMeasure(regular).n>0);assert.ok(firstDecisionMeasure(regular).missing>0);
 for(const t of annualTrends(regular,[2023,2024,2025,2026]))assert.ok(t.approvalPublication.n>0);
 assert.equal(summary(data.records.filter(r=>r.decision==='Arquivado'),ref).approvalPublication.n,0);
 const q=editorQueues(data.records,ref);assert.equal(q.groups.length,4);assert.equal(q.unassigned.length,0);assert.ok(q.groups.every(g=>g.rows.length>0));
});
test('HTML portátil sem solicitações de rede, credenciais ou dados editoriais reais',()=>{
 const html=fs.readFileSync(new URL('../Abrir-demonstracao.html',import.meta.url),'utf8');
 assert.ok(html.includes('DEMONSTRAÇÃO — DADOS FICTÍCIOS'));assert.ok(html.includes("connect-src 'none'"));
 for(const text of ['fetch(','XMLHttpRequest','WebSocket','/api/google','PRIVATE KEY'])assert.ok(!html.includes(text),text);
 assert.ok(!/<script[^>]+src=/.test(html));assert.ok(!/<link[^>]+href="https?:/.test(html));
});
console.log(JSON.stringify({records:data.records.length,reference:ref,counts:summary(data.records,ref).counts,editors:editorQueues(data.records,ref).groups.map(g=>({name:g.name,n:g.rows.length}))}));
