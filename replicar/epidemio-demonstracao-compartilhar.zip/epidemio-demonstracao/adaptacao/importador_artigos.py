"""Importa Artigos preservando lacunas e conferências da fonte."""
import argparse, collections, datetime as dt, hashlib, io, json, math, pathlib, re, unicodedata, uuid, zipfile
import openpyxl
HEADERS={'code':'Código','title':'Título','articleType':'Tipo de artigo','submitted':'Data da submissão','adjusted':'Data da adequação','firstWoman':'Primeiro autor é mulher?','anyWoman':'Algum autor é mulher?','institution':'Instituição do 1o. autor (sigla)','region':'UF da instituição do 1o. autor','status':'Status do momento','decision':'Decisão editorial final','decided':'Data da decisão editorial final','sentProduction':'Data do envio à Zeppelini','published':'Data da publicação na SciELO'}
DATE_FIELDS={'submitted','adjusted','decided','sentProduction','published'}
HEADERS.update(reviewersNominated='Algum EA já indicou revisores?',reviewInvitedAt='Data dos primeiros convites aos revisores',reviewCompletedAt='Data de conclusão da etapa de revisores (1a. rodada)',reviewInvited='No total, quantos revisores já foram convidados?',reviewAccepted='Quantos revisores já aceitaram?')
DATE_FIELDS.update({'reviewInvitedAt','reviewCompletedAt'})
OPTIONAL_FIELDS={'eic','firstDecisionDays','reviewReports'}
HEADERS.update(eic='EIC',firstDecisionDays='Dias para a primeira decisão',reviewReports='Revisores com emissão')
COUNT_FIELDS={'reviewInvited','reviewAccepted','reviewReports'}
def norm(value):return ' '.join(''.join(c for c in unicodedata.normalize('NFKD',str(value or '').replace('*','')) if not unicodedata.combining(c)).lower().split())
def stamp():return dt.datetime.now(dt.timezone.utc).isoformat()
def date_value(value):
 if value is None or value=='':return None
 if isinstance(value,dt.datetime):return value.date().isoformat()
 if isinstance(value,dt.date):return value.isoformat()
 if isinstance(value,str):
  for fmt in ('%d/%m/%Y','%Y-%m-%d','%d/%m/%y'):
   try:return dt.datetime.strptime(value.strip(),fmt).date().isoformat()
   except ValueError:pass
 raise ValueError('data ilegível')
def read_bytes(blob,filename,target_year=None):
 if len(blob)>15*1024*1024:raise ValueError('Arquivo excede 15 MB.')
 try:
  with zipfile.ZipFile(io.BytesIO(blob)) as z:
   if sum(i.file_size for i in z.infolist())>100*1024*1024:raise ValueError('Arquivo descompactado excede o limite de 100 MB.')
 except zipfile.BadZipFile:raise ValueError('Escolha um arquivo Excel .xlsx válido.')
 w=openpyxl.load_workbook(io.BytesIO(blob),data_only=True,read_only=True)
 if 'Artigos' not in w.sheetnames:raise ValueError('A aba Artigos não foi encontrada.')
 try:return read_rows(list(w['Artigos'].values),filename,target_year,hashlib.sha256(blob).hexdigest())
 finally:w.close()
def read_rows(values,filename,target_year=None,digest=None):
 iterator=iter(values);header=next(iterator,());index={norm(h):i for i,h in enumerate(header) if h is not None}
 if norm('EA já indicou revisores?') in index:index.setdefault(norm(HEADERS['reviewersNominated']),index[norm('EA já indicou revisores?')])
 missing=[h for key,h in HEADERS.items() if key not in OPTIONAL_FIELDS and norm(h) not in index]
 if missing:raise ValueError('Cabeçalhos ausentes: '+', '.join(missing))
 required_indices={index[norm(h)] for h in HEADERS.values() if norm(h) in index}
 code_index=index[norm(HEADERS['code'])]
 records=[]
 for rownum,row in enumerate(iterator,2):
  row=list(row)+[None]*max(0,max(index.values(),default=0)+1-len(row));code=row[index[norm(HEADERS['code'])]]
  if code is None or str(code).strip()=='':
   if any(row[i] is not None and row[i]!='' for i in required_indices):raise ValueError(f'Linha {rownum}: registro sem código. Corrija antes de importar.')
   continue
  if not any(row[i] is not None and row[i]!='' for i in required_indices if i!=code_index):continue
  r={'issues':[],'rawDates':{},'rawCounts':{}}
  for key,label in HEADERS.items():
   value=row[index[norm(label)]] if norm(label) in index else None
   if key in DATE_FIELDS:
    try:r[key]=date_value(value)
    except ValueError:r[key]=None;r['rawDates'][key]=str(value);r['issues'].append(f'{label}: valor ilegível preservado para conferência.')
   elif key=='firstDecisionDays':
    r[key]=None
    if value is not None and value!='':
     try:
      number=float(str(value).replace(',','.'))
      if not math.isfinite(number) or number<0:raise ValueError()
      r[key]=number
     except (ValueError,OverflowError):r['rawCounts'][key]=str(value);r['issues'].append(f'{label}: número inválido, excluído da média.')
   elif key in COUNT_FIELDS:
    r[key]=None
    if value is not None and value!='':
     try:
      number=float(str(value).replace(',','.'))
      if number<0 or not number.is_integer():raise ValueError()
      r[key]=int(number)
     except (ValueError,OverflowError):r['rawCounts'][key]=str(value);r['issues'].append(f'{label}: contagem inválida, excluída da média.')
   else:r[key]=' '.join(str(value or '').strip().split())
  match=re.match(r'^(20\d{2})-',r['code']);code_year=int(match.group(1)) if match else None
  year=target_year or code_year or (int(r['submitted'][:4]) if r['submitted'] else None)
  if not year:raise ValueError(f'Linha {rownum}: não foi possível identificar o ano. Informe o ano com --ano.')
  if target_year and code_year and code_year!=target_year:raise ValueError(f'Linha {rownum}: código {r["code"]} não pertence ao ano {target_year}.')
  r.update(year=year,yearBasis='explicit' if target_year else ('code' if code_year else 'submission'),source=filename,sourceRow=rownum,recordKey=f'{year}:{r["code"]}:{rownum}')
  if not r['submitted']:r['issues'].append('Data da submissão não informada.')
  elif int(r['submitted'][:4])!=year:r['issues'].append('Ano da submissão diverge do ano do código/coorte.')
  if not r['status'] and not r['decision']:r['issues'].append('Status e decisão não informados. Não classificado como em análise.')
  elif r['status'] and not r['decision']:r['issues'].append('Status preenchido sem decisão editorial.')
  for key in ('firstWoman','anyWoman','reviewersNominated'):
   if r[key] and norm(r[key]) not in ('sim','nao'):r['issues'].append(f'{HEADERS[key]}: categoria diferente de Sim/Não.')
   elif r[key]:r[key]='Sim' if norm(r[key])=='sim' else 'Não'
  if r['adjusted'] and r['submitted'] and r['adjusted']<r['submitted']:r['issues'].append('Adequação anterior à submissão original.')
  start=r['adjusted'] or r['submitted']
  if start and r['decided'] and r['decided']<start:r['issues'].append('Decisão anterior ao marco efetivo. Intervalo excluído das médias.')
  if r['published'] and start and r['published']<start:r['issues'].append('Publicação anterior ao marco efetivo. Intervalo excluído das médias.')
  if r['published'] and r['decided'] and r['published']<r['decided']:r['issues'].append('Publicação anterior à decisão. Intervalo excluído das médias.')
  if r['reviewInvitedAt'] and r['reviewCompletedAt'] and r['reviewCompletedAt']<r['reviewInvitedAt']:r['issues'].append('Conclusão da revisão anterior aos convites. Intervalo excluído da média.')
  if r['reviewInvited'] is not None and r['reviewAccepted'] is not None and r['reviewAccepted']>r['reviewInvited']:r['issues'].append('Aceites de revisores excedem convites. Conferir contagens.')
  records.append(r)
 if not records:raise ValueError('A aba Artigos não contém registros.')
 years=sorted({r['year'] for r in records})
 if len(years)!=1:raise ValueError('Envie uma planilha anual por vez. Foram identificados vários anos nos códigos.')
 counts=collections.Counter(r['code'] for r in records)
 for r in records:
  if counts[r['code']]>1:r['issues'].append('Código repetido na fonte. Registros preservados pela linha de origem.')
 meta={'filename':filename,'sheet':'Artigos','count':len(records),'years':years,'sha256':digest or hashlib.sha256(json.dumps(values,ensure_ascii=False,default=str).encode()).hexdigest(),'importedAt':stamp(),'missingSubmission':sum(not r['submitted'] for r in records),'yearMismatch':sum(bool(r['submitted'] and int(r['submitted'][:4])!=r['year']) for r in records),'missingClassification':sum(not r['status'] and not r['decision'] for r in records),'duplicateCodes':[k for k,v in counts.items() if v>1],'recordsWithIssues':sum(bool(r['issues']) for r in records)}
 return records,meta
def read_source(path):return read_bytes(path.read_bytes(),path.name)
def merge_dataset(old,records,meta):
 years=set(meta['years']);combined=[r for r in old.get('records',[]) if r['year'] not in years]+records
 sources=[s for s in old.get('sources',[]) if not set(s['years'])&years]+[meta];combined.sort(key=lambda r:(r['year'],r['code'],r['sourceRow']))
 return {**{k:v for k,v in old.items() if k not in {'records','sources'}},'schemaVersion':3,'revision':uuid.uuid4().hex,'preparedAt':stamp(),'yearBasis':'code_cohort','settings':old.get('settings',{'approvedGenderDenominator':'all_in_gender_group','noMeansMan':True,'excludeArchivedFromAnalysis':True}),'sources':sorted(sources,key=lambda s:s['years']),'records':combined}
def main():
 ap=argparse.ArgumentParser(description='Converte uma planilha anual, aba Artigos, para JSON. Não altera o painel.')
 ap.add_argument('arquivo',type=pathlib.Path)
 ap.add_argument('--ano',type=int)
 ap.add_argument('--saida',required=True,type=pathlib.Path)
 args=ap.parse_args()
 records,meta=read_bytes(args.arquivo.read_bytes(),args.arquivo.name,args.ano)
 data=merge_dataset({'records':[],'sources':[]},records,meta)
 args.saida.parent.mkdir(parents=True,exist_ok=True)
 try:
  with args.saida.open('x',encoding='utf-8') as dest:json.dump(data,dest,ensure_ascii=False,indent=2)
 except FileExistsError:ap.error('A saída já existe. Escolha outro nome para preservá-la.')
 print(f'Convertidos {len(records)} artigos. Registros com observações: {meta["recordsWithIssues"]}.')
if __name__=='__main__':main()
