# Escopo desta pasta

Este projeto é uma demonstração local exclusivamente com dados fictícios. Não conectar a fontes reais, copiar credenciais ou publicar sobre uma instância oficial. Preservar o aviso de demonstração e a identificação fictícia de registros e entidades. Trabalhos no painel oficial devem ocorrer em seu projeto separado.

Depois de editar dist/, regenerar Abrir-demonstracao.html com scripts/gerar_html_portatil.py e executar os testes pertinentes. Não incluir arquivos privados no pacote compartilhável.
