# Uma apresentação de aproximadamente três minutos

**Abertura — 20 segundos.** “Este painel apoia a gestão editorial da epidemio. Para apresentar a experiência, substituímos integralmente os registros por dados fictícios. Os números que veremos não representam resultados reais da revista.”

**Visão geral — 30 segundos.** Mostre recebidos, aprovados, recusados, arquivados e distribuição das etapas. Selecione somente 2026 para demonstrar a atualização conjunta dos indicadores. Explique que os arquivados aparecem no acompanhamento, mas ficam fora dos denominadores analíticos.

**Prazos em aberto — 35 segundos.** Apresente os alertas por etapa, o motivo de cada alerta e a identificação do editor responsável. Mostre a lista de artigos com 120 dias ou mais. Explique que esses quadros ajudam a priorizar o acompanhamento.

**Prazos editoriais — 35 segundos.** Mostre a média ao lado do boxplot, o filtro de tipo de artigo e a evolução anual. Explique que a média pode esconder dispersão e valores extremos; o número de registros válidos torna o cálculo verificável.

**Autoria e instituições — 35 segundos.** Percorra o mapa de submissões por UF e os pontos ordenados das instituições. As cores do mapa representam volume, não taxa por população. Mostre a distinção entre participação no total e aprovação dentro de uma categoria.

**Editores e conferência — 25 segundos.** Mostre as filas dos quatro editores fictícios e a conferência de campos incompletos. A proposta é tornar a informação útil para decisões e para melhorar o preenchimento da base.

**Fechamento.** “A estrutura pode ser adaptada a outras revistas, desde que se revisem os campos, as categorias e os critérios editoriais. A implantação com dados reais deve ter acesso restrito e conexão própria às fontes.”

Antes de gravar, clique em **Reiniciar demonstração**. Capture apenas a janela da demonstração e mantenha o aviso de dados fictícios visível. Não apresente estes números como uma avaliação do desempenho real da revista.
