"""Gera uma base independente. Não lê planilhas, arquivos de produção ou a rede."""
from pathlib import Path
from datetime import date,timedelta
import json,random,csv

ROOT=Path(__file__).resolve().parents[1]
REF=date(2026,11,19)
rng=random.Random(481937)
EDITORS=[f'Editor {x} (fictício)' for x in 'ABCD']
UFS=['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO']
TOPICS=['acesso a serviços de saúde','hábitos de atividade física','cuidado na atenção primária','bem-estar em comunidades','mobilidade e saúde','acompanhamento de condições crônicas','ambiente urbano e qualidade de vida','hábitos de sono','educação em saúde','alimentação e cotidiano','envelhecimento saudável','saúde no trabalho']
TYPES=['Número regular','Suplemento demonstrativo','Chamada temática fictícia']
HEADERS=['Código','Título','Autores','EIC','Tipo de artigo','Data da submissão','Data da adequação','Primeiro autor é mulher?','Algum autor é mulher?','Instituição do 1o. autor (sigla)','UF da instituição do 1o. autor','Status do momento','Decisão editorial final','Dias para a primeira decisão','Revisores com emissão','Data da decisão editorial final','Data do envio à Zeppelini','Data da publicação na SciELO','EA1 convidado (nome)','Data do envio do convite','Aceitou?','EA2 convidado (nome)','Data do envio do convite','Aceitou?','EA3 convidado (nome)','Data do envio do convite','Aceitou?','EA4 convidado (nome)','Data do envio do convite','Aceitou?','Algum EA já indicou revisores?','Data dos primeiros convites aos revisores','Data de conclusão da etapa de revisores (*1a. rodada*)','No total, quantos revisores já foram convidados?','Quantos revisores já aceitaram?','(uso interno - diferença de dias submissão e decisão)','(uso interno - diferença de dias decisão e publicação)','(uso interno - diferença de dias submissão e publicação)','(uso interno - em analise 90 dias)']
def iso(d):return d.isoformat() if d else None
def base(year,i,submitted=None):
 start=submitted or date(year,1,1)+timedelta(days=rng.randrange(100 if year==2026 else 300))
 adjusted=start+timedelta(days=rng.randint(3,17)) if i%5==0 else None
 first=rng.choices(['Sim','Não',''],[57,40,3])[0]
 inst=rng.choices(range(1,19),weights=[19,16,14,12,10,8,7,6,5,5,4,4,3,3,2,2,1,1])[0]
 region=rng.choices(UFS,weights=[2,3,2,4,9,6,4,5,5,4,4,3,14,5,4,10,8,3,12,3,11,2,1,8,17,2,3])[0]
 if i%61==0:region='Portugal'
 if i%67==0:region='Chile'
 if i%47==0:region=''
 return {'code':f'{year}-DEMO-{i:04d}','title':f'[Simulação {i:03d}] {TOPICS[(i+year)%len(TOPICS)].capitalize()}: estudo demonstrativo {year}',
 'authors':f'Autoria fictícia {i:04d}','year':year,'eic':EDITORS[(i+year)%4],
 'articleType':rng.choices(TYPES,[78,14,8])[0],'submitted':iso(start),'adjusted':iso(adjusted),
 'firstWoman':first,'anyWoman':'Sim' if first=='Sim' else rng.choices(['Sim','Não',''],[67,30,3])[0],
 'institution':f'Instituição Fictícia {inst:02d}' if i%53 else '', 'region':region,
 'status':'','decision':'','decided':None,'sentProduction':None,'published':None,'firstDecisionDays':None,
 'reviewersNominated':'','reviewInvitedAt':None,'reviewCompletedAt':None,'reviewInvited':None,'reviewAccepted':None,'reviewReports':None,
 'issues':[],'rawDates':{},'rawCounts':{},'source':f'Base fictícia {year}','sourceRow':i+1,'yearBasis':'code','recordKey':f'demo:{year}:{i}'}
def effective(r):return date.fromisoformat(r['adjusted'] or r['submitted'])
def close_record(r):
 start=effective(r);year=r['year']
 decision=rng.choices(['Aprovado','Recusa pelos ECs sem tramitação','Recusa pelo EA sem tramitação','Recusa após revisão','Arquivado'],[30,43,10,12,5])[0]
 duration={'Aprovado':rng.randint(65,155),'Recusa pelos ECs sem tramitação':rng.randint(5,32),'Recusa pelo EA sem tramitação':rng.randint(18,62),'Recusa após revisão':rng.randint(75,175),'Arquivado':rng.randint(7,70)}[decision]
 duration=max(1,duration-(year-2023)*4)
 r['decision']=decision;r['status']='Concluído publicado' if decision=='Aprovado' else 'Arquivado' if decision=='Arquivado' else 'Concluído recusado'
 r['decided']=iso(start+timedelta(days=duration));r['firstDecisionDays']=min(duration,rng.randint(8,43))
 if decision in ['Aprovado','Recusa após revisão']:
  invited=start+timedelta(days=rng.randint(12,21));completed=min(start+timedelta(days=duration-5),invited+timedelta(days=rng.randint(22,60)))
  r.update(reviewersNominated='Sim',reviewInvitedAt=iso(invited),reviewCompletedAt=iso(completed),reviewInvited=rng.randint(4,13),reviewAccepted=rng.randint(2,4),reviewReports=2)
 if decision=='Aprovado':
  decided=date.fromisoformat(r['decided']);r['sentProduction']=iso(decided+timedelta(days=5));r['published']=iso(decided+timedelta(days=rng.randint(20,60)))
 return r

def open_record(year,i,j):
 # Each first-round threshold is represented, together with cases below it.
 scenario=j%14
 ages=[26,35,135,145,52,68,95,170,190,8,12,34,160,80]
 age=ages[scenario] if year==2026 else 360+(j*9)
 r=base(year,i,REF-timedelta(days=age));r['adjusted']=None;r['articleType']='Número regular'
 statuses=['Aguardando EC (primeira análise)','Aguardando EA (definindo revisores)','Aguardando revisores (1a. rodada)','Aguardando EA (já com pareceres)','Aguardando revisores (1a. rodada)','Aguardando revisores (1a. rodada)','Em revisão pelos autores','Aguardando revisores (2a. ou 3a. rodada)','Aguardando EC (está com pareceres)','Aguardando EC (primeira análise)','Aguardando EA (definindo revisores)','Aguardando revisores (1a. rodada)','Aguardando EA (está com nova versão enviada)','Aguardando EA (já com pareceres)']
 r.update(status=statuses[scenario],decision='Ainda está em análise')
 if scenario not in [0,1,9,10]:
  invitation_age={2:65,3:80,4:20,5:55,6:60,7:110,8:120,11:7,12:90,13:55}[scenario]
  r.update(reviewersNominated='Sim',reviewInvitedAt=iso(REF-timedelta(days=invitation_age)),reviewInvited=6,reviewAccepted=0 if scenario==4 else None if scenario==5 else 2,reviewReports=0 if scenario in [2,4,5,11] else 2)
  if scenario in [3,6,7,8,12]:r['reviewCompletedAt']=iso(REF-timedelta(days=18 if scenario==3 else 38))
  if scenario in [6,7,8,12]:r['firstDecisionDays']=31
 if scenario==13:r['issues']=['Lacuna simulada: conclusão da primeira rodada não informada.']
 return r

records=[]
for year,n in [(2023,160),(2024,190),(2025,220),(2026,240)]:
 pending=0 if year<2025 else 4 if year==2025 else 28
 production=0 if year<2025 else 4 if year==2025 else 6
 unclassified=2 if year==2026 else 0
 closed=n-pending-production-unclassified
 rows=[close_record(base(year,i)) for i in range(1,closed+1)]
 rows += [open_record(year,closed+j+1,j+6 if year==2025 else j) for j in range(pending)]
 for j in range(production):
  i=closed+pending+j+1;r=base(year,i,date(year,9 if year<2026 else 5,1)+timedelta(days=j*3));r['adjusted']=None
  r.update(articleType='Número regular',decision='Aprovado',status='Com Zeppelini ou SciELO',decided=iso(REF-timedelta(days=20+j*6)),sentProduction=iso(REF-timedelta(days=15+j*6)),firstDecisionDays=35,reviewersNominated='Sim',reviewInvitedAt=iso(effective(r)+timedelta(days=25)),reviewCompletedAt=iso(effective(r)+timedelta(days=60)),reviewInvited=8,reviewAccepted=3,reviewReports=2)
  rows.append(r)
 for j in range(unclassified):
  r=base(year,n-j,REF-timedelta(days=3+j));r['adjusted']=None;r['issues']=['Lacuna simulada: classificação editorial ainda não preenchida.'];rows.append(r)
 records+=rows

sources=[{'filename':f'Cenário fictício {year}','sheet':'Artigos','years':[year],'count':sum(r['year']==year for r in records),'kind':'synthetic','importedAt':REF.isoformat()+'T12:00:00Z','missingSubmission':0,'yearMismatch':0,'missingClassification':sum(r['year']==year and not r['status'] for r in records),'duplicateCodes':[]} for year in range(2023,2027)]
dataset={'schemaVersion':3,'synthetic':True,'referenceDate':REF.isoformat(),'provenance':'Gerado do zero por regras e semente fixa; sem leitura, amostragem ou calibração por dados reais.','settings':{'approvedGenderDenominator':'all_in_gender_group','noMeansMan':True,'excludeArchivedFromAnalysis':True},'records':records,'sources':sources}
(ROOT/'dist/demo-data.js').write_text('export const DEMO_REFERENCE='+json.dumps(REF.isoformat())+';\nexport const DEMO_DATA='+json.dumps(dataset,ensure_ascii=False,separators=(',',':'))+';\n')

def br(v):return date.fromisoformat(v).strftime('%d/%m/%Y') if v else ''
def model_row(r):
 return [r['code'],r['title'],r['authors'],r['eic'],r['articleType'],br(r['submitted']),br(r['adjusted']),r['firstWoman'],r['anyWoman'],r['institution'],r['region'],r['status'],r['decision'],r['firstDecisionDays'],r['reviewReports'],br(r['decided']),br(r['sentProduction']),br(r['published'])]+['']*12+[r['reviewersNominated'],br(r['reviewInvitedAt']),br(r['reviewCompletedAt']),r['reviewInvited'],r['reviewAccepted']]+['']*4
sample=[next(r for r in records if r['year']==2026 and r['decision']==d and r['status']!='Com Zeppelini ou SciELO') for d in ['Aprovado','Recusa pelos ECs sem tramitação','Recusa pelo EA sem tramitação','Recusa após revisão','Arquivado']]+[r for r in records if r['year']==2026 and r['decision']=='Ainda está em análise'][:5]
sample_rows=[model_row(r) for r in sample]
(ROOT/'modelos/modelo-estrutura.json').write_text(json.dumps({'headers':HEADERS,'rows':sample_rows},ensure_ascii=False,indent=2))
with (ROOT/'modelos/Artigos-exemplo-ficticio.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(HEADERS);w.writerows(sample_rows)
print(f'Gerados {len(records)} artigos fictícios; referência {REF}. Nenhuma fonte real foi acessada.')
