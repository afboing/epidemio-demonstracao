"""Empacota os módulos locais em um HTML portátil, sem bibliotecas externas."""
from pathlib import Path
import re,base64
ROOT=Path(__file__).resolve().parents[1];DIST=ROOT/'dist'
order=['demo-data.js','metrics.js','charts.js','br-uf-paths.js','authorship-charts.js','app.js']
parts=['(async()=>{const modules={};']
for name in order:
 source=(DIST/name).read_text()
 exports=re.findall(r'^export (?:const|function) (\w+)',source,re.M)
 source=re.sub(r"^import \{([^}]+)\} from './([^']+)';",lambda m:'const {'+m[1]+"}=modules['"+m[2]+"'];",source,flags=re.M)
 source=re.sub(r'^export (?=(?:const|function) )','',source,flags=re.M)
 assert not re.search(r'^import |^export ',source,re.M),name
 parts.append("modules['"+name+"']="+('await (async()=>{' if name=='app.js' else '(()=>{')+'\n'+source+'\nreturn {'+','.join(exports)+'};})();')
parts.append('})();')
script='\n'.join(parts).replace('</script','<\\/script')
html=(DIST/'index.html').read_text()
logo='data:image/jpeg;base64,'+base64.b64encode((DIST/'assets/epidemio.jpg').read_bytes()).decode()
html=html.replace('assets/epidemio.jpg',logo).replace('<link rel="stylesheet" href="styles.css">','<style>'+(DIST/'styles.css').read_text()+'</style>')
html=html.replace("script-src 'self'","script-src 'unsafe-inline'")
html=html.replace('<script type="module" src="app.js"></script>','<script>'+script+'</script>')
(ROOT/'Abrir-demonstracao.html').write_text(html)
print('HTML portátil pronto. Abra com duplo clique; não requer servidor nem internet.')
